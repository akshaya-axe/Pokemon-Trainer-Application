<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Pokemon;
//use App\Http\Controllers\Pokemon;
use Redirect;
use Exception;

class addController extends Controller
{
    
public function add(Request $request) {
if(!$request->user()) {return Redirect::to('login');}
if ($request->user() && $request->user()->isAdmin) {return view('add');}
else {return Redirect::to('login');}
}

public function addpokemon(Request $request)
{

try{$pokemons= new Pokemon; $pokemons->poke_name=$request->input('pokemons');$pokemons->save();}
catch(Exception $e){
$error=$e->errorInfo[1];
if($error==1062)
{
return Redirect::to('admin')->with('errormesg','!!!Pokemon Already Exists...Try Again!!!');
}
}


return Redirect::to('admin')->with('updatedmesg','!!!Pokemon added successfully!!!');

}

}
