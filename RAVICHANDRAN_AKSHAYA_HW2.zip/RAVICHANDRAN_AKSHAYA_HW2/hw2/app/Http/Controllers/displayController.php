<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Pokemon;
use Redirect;

class displayController extends Controller
{
    //
public function display(Request $request)
{

if(!$request->user()) {return Redirect::to('login');}
if ($request->user() && $request->user()->isAdmin) {
$result=Pokemon::all();
return view('admin')->with('pokemons',$result);
}
else {return Redirect::to('login');}

}
}

