<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use Illuminate\App\User;
//use App\Http\Requests;
use App\User;
use App\Pokemon;
//use App\Http\Controllers\Auth;
//use App\Http\Controllers\Redirect;
//use illuminate\Support\Facades\Redirect;
use Redirect;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
	
if( !($request->user()) ) {return Redirect::to('login');}
if ($request->user() && $request->user()->isAdmin)
{
return Redirect::to('admin');
}

else	
{	$users= User::all();
	return view('home',compact('users'));
}
}

public function updateform($id)
{
$edit= User::find($id); $model=Pokemon::all();
//return view('home')->with('datas',$model);
return view('update')->with('users',$edit)->with('datas',$model);

}

public function updatedata(Request $formdata,$id)
{
$users=User::find($id);
$users->name=$formdata->input('name');
$users->email=$formdata->input('email');
$users->htown=$formdata->input('htown');
//$users->password=$formdata->input('pswd');
$users->pokemon()->associate(Pokemon::find($formdata->input('drop')));
//$users->pokemon=Pokemon::find($formdata->input('drop'));
$users->save();
return Redirect::to('home')->with('updatemesg','!!!Profile updated successfully!!!');
//echo "addadd";
}
}
