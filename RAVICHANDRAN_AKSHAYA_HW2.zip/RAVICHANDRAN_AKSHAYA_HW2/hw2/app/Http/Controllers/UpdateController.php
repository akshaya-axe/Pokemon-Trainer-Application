<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use Illuminate\App\User;
//use App\Http\Requests;
use App\User;
//use DB;

class UpdateController extends Controller
{

/**public function update(Request $request,$id)
{
$name=$request->input('name');
DB::update('update users set name= ? where id=?', [$name,$id]);

$email=$request->input('email');
DB::update('update users set email= ? where id=?', [$email,$id]);

$pswd=$request->input('pswd');
DB::update('update users set password= ? where id=?', [$pswd,$id]);

$htown=$request->input('htown');
DB::update('update users set htown= ? where id=?', [$htown,$id]);


echo "records updated successfully<br/>";
echo '<a href="/home">GO back</a>';

}**/

public function getForm()
{return view('update');
}
}











}
