<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Pokemon;
use Redirect;

class delController extends Controller
{
//
public function delete(Request $request)
{

if( !$request->user() ) {return Redirect::to('login');}
if ($request->user() && $request->user()->isAdmin)
{
$model=Pokemon::all();
return view('del')->with('datas',$model);
}
else 
{return Redirect::to('login');}
}

public function delpokemon(Request $request)
{
$value=$request->input('drop');
$model=Pokemon::find($value);

$model->delete();

//return ('deleted');
return Redirect::to('admin')->with('deletedmesg','!!!Pokemon deleted successfully!!!');

//return Redirect::to('del')->with('deletemsg','1 row deleted');
}
}


