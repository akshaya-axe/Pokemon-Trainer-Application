<!DOCTYPE html>
<html>
<head>
<title>Admin Add Pokemon Page</title>
</head>
<body>

<h2> Welcome Admin!</h2><p> <br> <br> You can now add pokemons into the system. </p>
<?php if(Session::has('message')): ?>
<span style="color:green"> <?php echo Session::get('message'); ?>

</span>
<?php endif; ?>

<div class="container">
<div class="content">
<h4> Enter the Pokemon Name you wish to add to the system :</h4> 
</br>
<form action="addpokemon" method="post">
<?php echo e(csrf_field()); ?>

<input type="text" name="pokemons" id="pokemons"> 
<input type="submit" value="ADD">
</form>
</div>
</div>
</body>
</html>
