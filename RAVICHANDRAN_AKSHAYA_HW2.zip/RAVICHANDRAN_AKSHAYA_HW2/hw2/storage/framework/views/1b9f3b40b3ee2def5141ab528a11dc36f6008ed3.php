<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <title>Admin Page</title>

    <!-- Styles -->
    <link href="/css/app.css" rel="stylesheet">

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>

<style>
ul { list-style-type:none; margin:0; padding:0;overflow: hidden; background-color:#DCF6F7;}
li {float:left;}
li a{ display:block; color:#000; text-align:center; padding: 10px 16px; text-decoration:none; }
li a:hover{background-color:#555; color:white;}
body {background: url("http://www.pocketmeta.com/wp-content/uploads/2016/07/Pokemapper.jpg") no-repeat center center fixed;-webkit-background-size: cover;-moz-background-size: cover;  -o-background-size: cover;  background-size: cover; }
table {
    border-collapse: collapse;
    width: 30%;
}

 td {
    text-align: center;
    padding: 8px;
font-size: 16px;

}
th{background-color: #17B9C2;
 text-align: center;
    padding: 8px;
font-size: 20px;
color:white;
}

tr:nth-child(even){background-color: #E3E8E8}
tr:nth-child(odd) {background-color: white}
fieldset{ display:inline-block; max-width=400px;padding:20px; border:1px solid transparent; margin-left: 630px; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px;   }

p {text-align: center; list-style-type:none; margin:0; padding:0;overflow: hidden;display:block; color:#F50505; text-align:center; padding: 10px 16px; text-decoration:none; font-size:25px; };

</style>

</head>


<body>

 <ul class="dropdown-menu" role="menu">
      <li>
     <a href="<?php echo e(url('/logout')); ?>"
   onclick="event.preventDefault();
       document.getElementById('logout-form').submit();">                                  Logout
      </a>
  <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
           <?php echo e(csrf_field()); ?>

         </form>
  </li>
       </ul>
<h2><span style="margin-left:720px;color:#F55905;"> <u> Welcome Admin! </u></h2> </span><br>

<?php $count= DB::table('pokemons')->distinct('id')->count('id'); ?>
<div><fieldset><span style="color: #F50505; font-size:18px;background-color:#F5C9C9;">There are currently <b> <?php echo $count ?> </b> pokemons in the system!</fieldset></span></div>
<br>
<?php if(Session::has('updatedmesg')): ?>
<p class="alert alert-info"><span style="color:#006400;"><b><?php echo e(Session::get('updatedmesg')); ?></p></b>
</span>
<?php endif; ?>

<?php if(Session::has('deletedmesg')): ?>
<p class="alert alert-info"><span style="color:#006400;"><b> <?php echo e(Session::get('deletedmesg')); ?></p></b>
</span>
<?php endif; ?>

<?php if(Session::has('errormesg')): ?>
<p class="alert alert-info"><span style="color:red;background-color:white;"><b> <?php echo e(Session::get('errormesg')); ?></p></b>
</span>
<?php endif; ?>

<div class="container">

<div class="content">
<table border="1px" align="center">
<tr>
<th> Pokemon </th>
<th>Pokemon Name </th>

</tr>
<?php 
foreach ($pokemons as $values)
{
?>
<tr>
<td><?php echo $values->id; ?> </td>
<td> <?php echo $values->poke_name; ?> </td> 
</tr>
<?php
}
?>
</table>
<br><h4> <span style="margin-left:630px;color:#F55905;background-color:#F2CEA7;">
<img src="http://www.isujcv.ro/Pagini/Prima%20pagina/Exclamation_mark_red.png" width="30px" heoght="50px";/> Click to add pokemons into the system.

<a href= "<?php echo url('add');?>"> ADD </a>  <br></span>

<span style="margin-left:630px;color:#F55905;background-color:#F2CEA7;">
<img src="http://www.isujcv.ro/Pagini/Prima%20pagina/Exclamation_mark_red.png" width="30px" heoght="50px";/> Click to delete pokemons from the system. 

<a href= "<?php echo url('delete');?>"> DELETE </a> </h4></span>



</div>
</div>
</body>
</html>
