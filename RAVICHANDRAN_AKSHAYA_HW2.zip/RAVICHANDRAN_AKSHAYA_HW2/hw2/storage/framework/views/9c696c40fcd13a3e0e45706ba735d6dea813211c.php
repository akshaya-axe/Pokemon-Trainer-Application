<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="/css/app.css" rel="stylesheet">

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>

<style>
body {background: url("http://img03.deviantart.net/f7c9/i/2010/335/5/c/pokeball_wallpaper_2_by_aervormund-d3415su.png") no-repeat center center fixed ;-webkit-background-size: cover;
  -moz-background-size: cover;  -o-background-size: cover;  background-size: cover; }
fieldset{ display:inline-block; max-width=400px;padding:50px; border:2px solid transparent; margin-left: 650px; -moz-border-radius:8px; -webkit-border-radius:8px; border-radius:8px;   }
p {text-align: center; list-style-type:none; margin:0; padding:0;overflow: hidden;display:block; color:white; text-align:center; padding: 10px 16px; text-decoration:none; font-size:25px; };

</style>

</head>
<body>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default"><fieldset>
                <div class="panel-heading"></div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label"><span style="color:white;font-size:20px;">Name</span></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label"><span style="color:white;font-size:20px;">E-Mail Address</span></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label"><span style="color:white;font-size:20px;">Password</span></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>







                        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                            <label for="password-confirm" class="col-md-4 control-label"><span style="color:white;font-size:20px;">Confirm Password</span></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>

                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


 		<div class="form-group<?php echo e($errors->has('htown') ? ' has-error' : ''); ?>">
                            <label for="htown" class="col-md-4 control-label"><span style="color:white;font-size:20px;">Hometown</span></label>

                            <div class="col-md-6">
                                <input id="htown" type="text" class="form-control" name="htown" value="<?php echo e(old('htown')); ?>" required>

                                <?php if($errors->has('htown')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('htown')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                  	</div>

<br><br>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                 <span style="color:red;padding:10px;font-size:20px;">   Register</span>
                                </button>
                            </div>
                        </div>
                    </form></fieldset>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>