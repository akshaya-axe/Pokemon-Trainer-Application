<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index');

Auth::routes();

Route::get('/home', 'HomeController@index');

Auth::routes();

Route::get('/home', 'HomeController@index');

Auth::routes();

Route::get('/home', 'HomeController@index');

Auth::routes();

Route::get('/home', 'HomeController@index');



Route::get('editform/{id}','HomeController@updateform');
Route::post('update/{id}','HomeController@updatedata');

Route::get('add','addController@add');
Route::post('addpokemon','addController@addpokemon');

Route::get('admin','displayController@display');

Route::get('delete','delController@delete');
Route::post('delpokemon','delController@delpokemon');


