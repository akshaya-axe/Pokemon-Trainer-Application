<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">


    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    <link href="/css/app.css" rel="stylesheet">

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>

<style>
body {background: url("http://img03.deviantart.net/f7c9/i/2010/335/5/c/pokeball_wallpaper_2_by_aervormund-d3415su.png") no-repeat center center fixed ;-webkit-background-size: cover;
  -moz-background-size: cover;  -o-background-size: cover;  background-size: cover; }
fieldset{ display:inline-block; max-width=400px;padding:50px; border:2px solid transparent; margin-left: 650px; -moz-border-radius:8px; -webkit-border-radius:8px; border-radius:8px;   }
p {text-align: center; list-style-type:none; margin:0; padding:0;overflow: hidden;display:block; color:white; text-align:center; padding: 10px 16px; text-decoration:none; font-size:25px; };

</style>

</head>
<body>
@extends('layouts.app')

@section('content')
<div class="container" >
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
<br><br><br><br><br>

<p><u> Welcome to Pokemon Trainer Management System </u> </p><br>
                <div class="panel-heading"> <!--<h3 style="margin-left:700px;color:white;">Login </h3> --></div>
                <div class="panel-body"><fieldset>
                    <form class="form-horizontal" role="form" method="POST" action="{{ url('/login') }}">
                        {{ csrf_field() }}
                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label"> <span style="color:white;">Enter E-Mail Address : </span></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong><span style="color:white;">{{ $errors->first('email') }}</span></strong>
                                    </span>
                                @endif
                            </div>
                        </div>
<br> 
                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label"> <span style="color:white;">Enter Password :</label></span>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong><span style="color:white;">{{ $errors->first('password') }}</span></strong>
                                    </span>
                                @endif
                            </div>
                        </div>
<br>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember"> Remember Me
                                    </label>
                                </div>
                            </div>
                        </div>
<br>
                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" style="width:90px; height:40px; background-color:black;color:white;font-size:20px;">
                                  Login
                                </button>
<br>
                                <a class="btn btn-link" href="{{ url('/password/reset') }}">
                                    Forgot Your Password?
                                </a>
                            </div>
                        </div>
                 </fieldset>   </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
