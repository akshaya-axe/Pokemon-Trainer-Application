
<!DOCTYPE html>
<html>
<head>
<title>Delete pokemons</title>
<style>
fieldset{ display:inline-block; max-width=400px;padding:20px; border:2px solid #939696; margin-left: 640px; margin-top:200px; ;-moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; color:white;  }
body{background: url("http://i.ytimg.com/vi/AowYEKIESiY/maxresdefault.jpg") no-repeat center center fixed;-webkit-background-size: cover;-moz-background-size: cover;  -o-background-size: cover;  background-size: cover; }
form{margin:0 auto; width:250px; padding-left:60px;}
#submit{border:0 none; cursor: pointer; -webkit-border-radius: 10px;border-radius:10px; background:#6E7070;padding:5px; color:white;}
#sel {border:0 none; cursor: pointer; -webkit-border-radius: 7px;border-radius:7px; padding:7px; }
</style>
</head>
<body>
<div class="container">
<div class="content">
<fieldset>
<h3 style="color:white;"> Select the pokemon you want to delete</h3> 
</br>

<form action="delpokemon" method="post"> {{csrf_field() }}


<select name="drop" id="sel">

<?php 

foreach ($datas as $values){

?>
<option  value="<?php echo $values->id; ?>">
<?php echo $values->poke_name;?> </option>
<?php

}
?>
</select></br>
<span style="padding-left:20px;"><input type="submit" id="submit" value="DELETE"></span>
</form>
</fieldset>
</div>
</div>
</body>
</html>

