<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

   
    <!-- Styles -->
    <link href="/css/app.css" rel="stylesheet">

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>

<style>
body{background: url("http://hot-wallpapers-hd.com/wp-content/uploads/2013/09/8-bit-Ash-and-Pikachu-Toaster-HD-Wallpaper.png")no-repeat center center fixed;-webkit-background-size: cover;-moz-background-size: cover;  -o-background-size: cover;  background-size: cover; }
fieldset{ display:inline-block; width=100%;padding:30px; border:3px solid black; color:black;margin-left: 630px; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; }
form{margin:0 auto; width:300px; font-size:20px;}
#submit{border:0 none; cursor: pointer; -webkit-border-radius: 10px;border-radius:10px; background:black;padding:5px; color:white; font-size:20px;}
#sel {border:0 none; cursor: pointer; -webkit-border-radius: 7px;border-radius:7px; padding:7px; }
</style>
</head>
<body>
   
<div class="container">
<div class="row">
<fieldset>
@if(Session::has('message'))
<span style="color:green"> {!!Session::get('message')!!}
</span>
@endif

{!!Form::open(array('url'=>['update',$users->id]));!!}
Enter Name <input type="text" name="name" value="<?php echo $users->name;?>" placeholder="Name">
<br><br>
Enter Email ID<input type="text" name="email" value="<?php echo $users->email;?>" placeholder="Email id"> 
<br>
<!--<br>
Enter New Password
<input type="text" name="pswd" placeholder="password">
<br>-->
<br>
Enter Hometown <input type="text" name="htown" value="<?php echo $users->htown;?>" placeholder="Hometown"> 
<br><br>
Select Pokemon<select name="drop" id="sel">
<?php 
foreach ($datas as $values)
{
?>
<option value="<?php echo $values->id; ?>"> 
<?php echo $values->poke_name;?>
</option>
<?php }
?>
</select>
<br>
<br>
<span style="font-size:30px";><input type="submit"  id="submit" value="Update Profile"> </span>

{!!Form::close()!!}
</fieldset>

</div>
</div>

</body>
</html>



