
<style>
th
{background-color:#90c5d4;}
tr:hover {background-color: #818181;}
#image{
-webkit-background-size: cover;-moz-background-size: cover;  -o-background-size: cover;  background-size: cover; 

position: absolute;    left: 0;    top: 0;    width: 100%;    height: auto;  }

ul { list-style-type:none; margin:0; padding:0;overflow: hidden; background-color:#f1f1f1;}
li {float:left;}
li a{ display:block; color:#000; text-align:center; padding: 10px 16px; text-decoration:none; }
li a:hover{background-color:#555; color:white;}
table {
    border-collapse: collapse;
    width: 30%;
margin-left: 500px;
}

a.link:visited{color:blue;}
a.link:hover{color:green;}


 td {
    text-align: center;
    padding: 8px;
font-size: 16px;

}
th{background-color: #55C1E6;
 text-align: center;
    padding: 8px;
font-size: 20px;
color:white;
}

tr:nth-child(even){background-color: #E3E8E8}
tr:nth-child(odd) {background-color: white}
fieldset{ display:inline-block; max-width=400px;padding:20px; border:1px solid transparent; margin-left: 630px; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px;   }

</style>
<body id="image" background ="http://wallpapercave.com/wp/UTEF6XR.png" center no-repeat fixed>


@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
               

                <div class="panel-body">
                  <span style="background-color:#0C85AD;color:white;font-size:20px;">  You are logged in! </span> <br><span style="background-color:#564567;color:white;font-size:20px;margin-left:670px;">  Welcome to Login Page  </span>
                </div>
<br>

<div class="container">
<div class="row">
<div class="col-md-8 ">

<br>

@if(Session::has('updatemesg'))
<p class="alert alert-info"><span style="color:#006400;padding-left:600px;font-size:18px;"> <b>{{Session::get('updatemesg')}}</p></b>
</span>     
@endif


<table cellpadding="20" border="2px solid black" > 
<tr>
<th> NAME </th>
<th> HOMETOWN </th>
<th> POKEMON </th>
<th> ADMIN </th>
<th> ACTION </th> 
</tr>
<tr>
<!--<td>{{ Auth::user()->name }}</td>
$u=Auth::user();
<td> {{ Auth::user()->htown }}</td>
<td> {{ Auth::user()->name }}</td>
@if (Auth::user()->isAdmin == 0)
<td> No </td>
@elseif (Auth::user()->isAdmin == 1)
<td> Yes </td>
@endif
<td><a href="#">EDIT</a></td>
</tr>
-->


<tr>
@foreach ($users as $usr)
<td>{{ $usr->name }}</td>
<td> {{ $usr->htown }}</td>
<td> {{ $usr->pokemon ? $usr->pokemon->poke_name : ''}}</td>
@if ($usr->isAdmin == 0)
<td> No </td>
@elseif ( $usr->isAdmin == 1)
<td><span style="background-color:#ed6668";> Yes </td></span>
@endif

@if ($usr->name === Auth::user()->name)
<td><a class="link" href= "<?php echo url('editform');?>/<?php echo $usr->id;?>"> EDIT </a></td>
@else
<td> N/A </td>
@endif

</tr>
@endforeach
</div>
</div>
</div>
</table>

</div>
</div>
</div>
</div>
</body>
@endsection
