<!DOCTYPE html>
<html>
<head>
<title>Add pokemons</title>
<style>
fieldset{ display:inline-block; max-width=400px;padding:20px; border:2px solid #939696; margin-left: 650px; margin-top:200px; ;-moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; color:white;  }
body{background: url("http://i.ytimg.com/vi/AowYEKIESiY/maxresdefault.jpg") no-repeat center center fixed;-webkit-background-size: cover;-moz-background-size: cover;  -o-background-size: cover;  background-size: cover; }
form{margin:0 auto; width:250px;}
#submit{
border:0 none; cursor: pointer; -webkit-border-radius: 10px;border-radius:10px; background:#ccc;padding:4px;
}
</style>
</head>
<body>
<div class="container">
<div class="content">

</br>

<fieldset> 


<h4> Enter the Pokemon Name:(Case-sensitive) </h4> 
</br>
<form action="addpokemon" method="post">{{csrf_field() }}
<input type="text" name="pokemons" id="pokemons"> <br>
<span style="padding-left:80px;"><input type="submit" id="submit" value="ADD" ></span>
</form>
</fieldset>
</div>
</div>
</body>
</html>
