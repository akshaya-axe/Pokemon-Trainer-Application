-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1build0.15.04.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 26, 2016 at 05:53 PM
-- Server version: 5.6.28-0ubuntu0.15.04.1
-- PHP Version: 5.6.4-4ubuntu6.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hw2db`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2013_09_20_194910_create_pokemon_table', 1),
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pokemons`
--

CREATE TABLE IF NOT EXISTS `pokemons` (
`id` int(10) unsigned NOT NULL,
  `poke_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pokemons`
--

INSERT INTO `pokemons` (`id`, `poke_name`, `created_at`, `updated_at`) VALUES
(1, 'pikachu', '2016-09-24 07:32:40', '2016-09-24 07:32:40'),
(2, 'snorlax', '2016-09-24 07:32:51', '2016-09-24 07:32:51'),
(4, 'dratini', '2016-09-24 10:25:46', '2016-09-24 10:25:46'),
(8, 'Dragonite', '2016-09-25 07:54:43', '2016-09-25 07:54:43'),
(10, 'Charizard', '2016-09-25 14:55:11', '2016-09-25 14:55:11'),
(12, 'magmar', '2016-09-25 14:58:00', '2016-09-25 14:58:00'),
(20, 'Staryu', '2016-09-25 15:34:39', '2016-09-25 15:34:39'),
(22, 'raichu', '2016-09-27 06:05:07', '2016-09-27 06:05:07');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `htown` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pokemon_id` int(10) unsigned DEFAULT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `htown`, `pokemon_id`, `isAdmin`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'ash', 'ash@gmail.com', '$2y$10$1jRiEUSlt7UQoXn68sFeVuTUHSOAmNycdJAg3py34l7c8VgLVEr7m', 'pallet town', 1, 0, '9oB1vdzbkPEzQPwsLD5q0OmSv69lFAWJ254muhbwAYAvFtQ1uOqaWRrbbUwu', '2016-09-24 07:30:10', '2016-09-27 07:24:14'),
(2, 'as', 'assdf@gmail.com', 'asdfgh', 'asiokmx', 2, 0, 'LSiJbNhhuDHkwPlxZb4cpam0qNTU8jPyPprue1nRe8N5zsUUtjXYO0A6eyG8', '2016-09-24 07:39:50', '2016-09-24 08:08:40'),
(3, 'joy', 'joy@gmail.com', 'asdfgh', 'pallet', 4, 0, 'kQNqgy7U6aaslbAE8m01F9PAdoDKkNwhcEzS4aWypJHL45F43Y0D905bKUkI', '2016-09-24 10:28:52', '2016-09-24 10:29:30'),
(4, 'oak', 'oak@gmail.com', '$2y$10$O1eul89TnUGDGzzYtImvK.a6R10gBtgBbkOgSHeKM9AQcmDSBoX3S', 'oak city', 2, 0, 'AsQe1MmLA5Mkx9eAJsk4ivzMIVpvKwMP5vRe2JkpAk9yHy1p3grDEy0iYjW5', '2016-09-25 09:11:37', '2016-09-27 05:44:51'),
(5, 'Misty', 'misty@gmail.com', '$2y$10$y9QOAOUwXE5/lkncZpIlBe1aGDUXRaJ8SEOC6bIwMEleuCdxR3.we', 'Cerulean City', 1, 1, 'jadcRfm9hVD6ymrjoKLRXdFJQhRUsWaT1p019TcqWBgd8fNrSVvwMYfh9O73', '2016-09-25 15:31:57', '2016-09-27 07:19:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
 ADD KEY `password_resets_email_index` (`email`), ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `pokemons`
--
ALTER TABLE `pokemons`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `pokemons_poke_name_unique` (`poke_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`), ADD KEY `users_pokemon_id_foreign` (`pokemon_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pokemons`
--
ALTER TABLE `pokemons`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `users`
--
ALTER TABLE `users`
ADD CONSTRAINT `users_pokemon_id_foreign` FOREIGN KEY (`pokemon_id`) REFERENCES `pokemons` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
