- I have implemented the new specifications wherein the relationship between Pokemon and Users is 1 to many. 
- Users table (pre-made) has been editted to include isAdmin (boolean) to check if the user is an admin or not, homwtown (string) and poke_id (foreign key index to pokemon table) 
- If a user is an admin (=1), then they are redirected to admin page. In the admin page, a user is allowed to view the number of pokemons in the system ,the pokemons in the system and can also   
add and delete pokemons. 
- Success messages are shown for both add and delete in admin page upon successful add/delete. 
- In case admin adds pokemons that have been already added (case-sensitive) error message is displayed.
- In the home page, a logged-in user can view all other user profiles which are registered in the system. But they can only edit their own profile (be it admin or a user).
- In edit page, users can change their name,email-id, hometown and only add pokemons that are registered into the system by an admin. Successful update message is shown in home page on successful updation.
- In-built css and js provided by laravel was not used. I have added in my own inline css styles. 

